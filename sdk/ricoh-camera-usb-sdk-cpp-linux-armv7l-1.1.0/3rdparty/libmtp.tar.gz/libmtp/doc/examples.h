/*
 * List examples here...
 */
/** \example delfile.c */
/** \example detect.c */
/** \example files.c */
/** \example folders.c */
/** \example getfile.c */
/** \example hotplug.c */
/** \example newfolder.c */
/** \example sendfile.c */
/** \example sendtr.c */
/** \example tracks.c */
/** \example trexist.c */
/** \example playlists.c */
/** \example getplaylist.c */
/** \example refactortest.c */
